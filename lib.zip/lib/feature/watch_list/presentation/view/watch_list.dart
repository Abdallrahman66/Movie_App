import 'package:flutter/material.dart';

import 'package:movie_app/feature/menu_drawer/view/menu_drawer_screen%20.dart';

import 'package:movie_app/core/common/app_bar.dart';

import '../../../../core/utils/app_colors.dart';

class WatchList extends StatelessWidget {
  static const String routeName = "WatchList";
  const WatchList({super.key});

  @override
  Widget build(context) {
    return Scaffold(
      backgroundColor: AppColor.backgroundColor,
      endDrawer: MenuDrawer(),
      appBar: CustomAppBar(title: "Watch List"),
    );
  }
}
